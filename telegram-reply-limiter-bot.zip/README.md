# Telegram Reply Limiter Bot

This Telegram bot allows only 2 replies to any message in a group. On the 3rd reply, it automatically deletes it.

## Setup Instructions

1. Replace `YOUR_BOT_TOKEN_HERE` in `main.py` with your actual Telegram bot token.
2. Install requirements:

```
pip install -r requirements.txt
```

3. Run the bot:

```
python main.py
```