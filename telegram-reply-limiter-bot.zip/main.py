from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, filters, ContextTypes
from collections import defaultdict

reply_counts = defaultdict(int)

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.reply_to_message:
        original_msg_id = update.message.reply_to_message.message_id
        reply_counts[original_msg_id] += 1

        if reply_counts[original_msg_id] > 2:
            await update.message.delete()

BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"

app = ApplicationBuilder().token(BOT_TOKEN).build()
app.add_handler(MessageHandler(filters.TEXT & filters.REPLY, handle_message))

print("Bot is running...")
app.run_polling()